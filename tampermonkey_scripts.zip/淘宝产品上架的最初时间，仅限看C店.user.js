// ==UserScript==
// @name         淘宝产品上架的最初时间，仅限看C店
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include      *://*.taobao.com/*
// @grant        none
// @require      https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js
// @require      https://cdn.jsdelivr.net/npm/sweetalert2@9
// ==/UserScript==

window.onload=(function() {
    'use strict';
var obj = eval(g_config);
var shijian = obj.idata.item.dbst;
var shijianzhuanhuan = new Date(shijian).toLocaleString();
alert("这个宝贝最初上架时间是"+shijianzhuanhuan)

    // Your code here...
})();